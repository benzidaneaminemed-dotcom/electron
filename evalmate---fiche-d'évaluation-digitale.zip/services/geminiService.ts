import { GoogleGenAI } from "@google/genai";
import { EvaluationData } from "../types";

// Initialize the client with the API key from the environment
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generatePerformanceSummary = async (data: EvaluationData): Promise<string> => {
  try {
    const prompt = `
      Agis en tant que responsable RH expert. Analyse les données d'évaluation mensuelle suivantes pour un(e) caissier(e) et rédige un résumé professionnel et constructif (environ 100 mots) pour la section "Commentaires globaux du responsable".

      **Données de l'employé :**
      - Nom : ${data.employee.name}
      - Période : ${data.employee.periodStart} au ${data.employee.periodEnd}

      **Assiduité :**
      - Nombre de retards : ${data.latenessList.length}
      - Total minutes de retard : ${data.latenessList.reduce((acc, curr) => acc + curr.delayMinutes, 0)} minutes
      - Commentaires assiduité : ${data.latenessComments}

      **Qualité de travail (Erreurs) :**
      - Nombre d'erreurs : ${data.errorList.length}
      - Erreurs répétées : ${data.errorList.filter(e => e.isRepeated).length}

      **Discipline :**
      - Avertissements : ${data.warnings.length}
      - Motifs : ${data.warnings.map(w => w.reason).join(', ')}

      **Conclusion :**
      - Prime de performance accordée : ${data.performanceBonus ? 'OUI' : 'NON'}

      **Consignes de rédaction :**
      Sois équilibré. Mentionne les points positifs s'il y a peu d'erreurs, mais sois ferme sur les retards ou les fautes graves. Si la prime est refusée, explique clairement pourquoi de manière professionnelle. Utilise un ton formel adapté à une fiche d'évaluation.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Impossible de générer le résumé.";
  } catch (error) {
    console.error("Error generating summary:", error);
    return "Erreur lors de la connexion à l'assistant IA. Veuillez rédiger le commentaire manuellement.";
  }
};

export const generateTeamBriefing = async (data: EvaluationData, period: string): Promise<string> => {
    try {
        const prompt = `
          Agis en tant que manager d'équipe de caissiers. 
          Basé sur les incidents types relevés dans cette fiche individuelle (exemple : ${data.latenessList.length} retards, ${data.errorList.length} erreurs de caisse),
          génère un briefing d'équipe ou une note de service simulée pour une période de : **${period}**.
          
          L'objectif est de rappeler les règles à TOUTE l'équipe pour éviter ce genre d'incidents, sans nommer l'employé spécifique.
          
          Structure de la réponse :
          1. Titre : Briefing d'équipe - Période : ${period}
          2. Points d'attention (basés sur les erreurs/retards observés ici).
          3. Objectifs pour la période (${period}).
          4. Mot d'encouragement.
          
          Ton : Professionnel, encourageant mais ferme sur les règles. Court et impactant.
        `;
    
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
        });
    
        return response.text || "Impossible de générer l'analyse d'équipe.";
      } catch (error) {
        console.error("Error generating team briefing:", error);
        return "Erreur IA.";
      }
};