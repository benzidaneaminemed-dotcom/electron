import React from 'react';

interface CardProps {
  title?: string;
  children: React.ReactNode;
  className?: string;
  action?: React.ReactNode;
}

export const Card: React.FC<CardProps> = ({ title, children, className = "", action }) => {
  return (
    <div className={`bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-4 ${className}`}>
      {(title || action) && (
        <div className="px-4 py-3 border-b border-gray-100 flex justify-between items-center bg-gray-50">
          {title && <h3 className="font-semibold text-gray-700 uppercase text-sm tracking-wider">{title}</h3>}
          {action && <div>{action}</div>}
        </div>
      )}
      <div className="p-4">
        {children}
      </div>
    </div>
  );
};
