import React, { useState } from 'react';
import { 
  User, AlertTriangle, CheckCircle, 
  XCircle, Plus, Trash2, FileText, Save, Wand2, Upload, PenTool, DownloadCloud,
  Users, Calendar
} from 'lucide-react';
import { Card } from './components/ui/Card';
import { SignatureModal } from './components/ui/SignatureModal';
import { generatePerformanceSummary, generateTeamBriefing } from './services/geminiService';
import { 
  EvaluationData, LatenessEntry, ErrorEntry, WarningEntry 
} from './types';
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";

const App: React.FC = () => {
  // --- State ---
  const [data, setData] = useState<EvaluationData>({
    employee: {
      periodStart: '',
      periodEnd: '',
      name: '',
      id: '',
      manager: '',
      photoUrl: ''
    },
    latenessList: [],
    latenessComments: '',
    errorList: [],
    warnings: [],
    performanceBonus: true,
    globalComments: '',
    managerSignature: '',
    employeeSignature: '',
    signatureDate: new Date().toISOString().split('T')[0]
  });

  const [isGenerating, setIsGenerating] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  
  // Team Analysis State
  const [teamAnalysisResult, setTeamAnalysisResult] = useState("");
  const [isAnalyzingTeam, setIsAnalyzingTeam] = useState(false);

  // Signature Modal State
  const [signingTarget, setSigningTarget] = useState<{
    type: 'lateness' | 'error' | 'warning' | 'main_employee' | 'main_manager';
    id?: string;
    title: string;
  } | null>(null);

  // --- Calculation Logic ---

  const calculateDelay = (expected: string, actual: string): number => {
    if (!expected || !actual) return 0;
    const [h1, m1] = expected.split(':').map(Number);
    const [h2, m2] = actual.split(':').map(Number);
    const expectedMin = h1 * 60 + m1;
    const actualMin = h2 * 60 + m2;
    return Math.max(0, actualMin - expectedMin);
  };

  // Note: Auto-calculation for performanceBonus has been removed to allow manual selection.

  // --- Handlers ---

  const handleEmployeeChange = (field: string, value: string) => {
    setData(prev => ({ ...prev, employee: { ...prev.employee, [field]: value } }));
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setData(prev => ({ ...prev, employee: { ...prev.employee, photoUrl: url } }));
    }
  };

  // Signature Handlers
  const openSignatureModal = (type: typeof signingTarget.type, id?: string, title: string = 'Signature') => {
    setSigningTarget({ type, id, title });
  };

  const handleSignatureSave = (signatureDataUrl: string) => {
    if (!signingTarget) return;

    const { type, id } = signingTarget;

    if (type === 'lateness' && id) {
        updateLateness(id, 'signature', signatureDataUrl);
    } else if (type === 'error' && id) {
        updateError(id, 'signature', signatureDataUrl);
    } else if (type === 'warning' && id) {
        updateWarning(id, 'signature', signatureDataUrl);
    } else if (type === 'main_employee') {
        setData(prev => ({ ...prev, employeeSignature: signatureDataUrl }));
    } else if (type === 'main_manager') {
        setData(prev => ({ ...prev, managerSignature: signatureDataUrl }));
    }
    setSigningTarget(null); // Close modal
  };

  // Lateness Handlers
  const addLateness = () => {
    const newEntry: LatenessEntry = {
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0],
      expectedTime: '08:00',
      actualTime: '08:00',
      delayMinutes: 0,
      reason: '',
      signature: ''
    };
    setData(prev => ({ ...prev, latenessList: [...prev.latenessList, newEntry] }));
  };

  const updateLateness = (id: string, field: keyof LatenessEntry, value: string | number) => {
    setData(prev => ({
      ...prev,
      latenessList: prev.latenessList.map(item => {
        if (item.id !== id) return item;
        const updated = { ...item, [field]: value };
        if (field === 'expectedTime' || field === 'actualTime') {
          updated.delayMinutes = calculateDelay(updated.expectedTime, updated.actualTime);
        }
        return updated;
      })
    }));
  };

  const removeLateness = (id: string) => {
    setData(prev => ({ ...prev, latenessList: prev.latenessList.filter(i => i.id !== id) }));
  };

  // Error Handlers
  const addError = () => {
    const newEntry: ErrorEntry = {
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0],
      nature: '',
      isRepeated: false,
      signature: ''
    };
    setData(prev => ({ ...prev, errorList: [...prev.errorList, newEntry] }));
  };

  const updateError = (id: string, field: keyof ErrorEntry, value: any) => {
    setData(prev => ({
      ...prev,
      errorList: prev.errorList.map(item => item.id === id ? { ...item, [field]: value } : item)
    }));
  };

  const removeError = (id: string) => {
    setData(prev => ({ ...prev, errorList: prev.errorList.filter(i => i.id !== id) }));
  };

  // Warning Handlers
  const addWarning = () => {
    setData(prev => ({
      ...prev,
      warnings: [...prev.warnings, { 
        id: Date.now().toString(), 
        date: new Date().toISOString().split('T')[0], 
        reason: '',
        signature: ''
      }]
    }));
  };

  const updateWarning = (id: string, field: keyof WarningEntry, value: string) => {
    setData(prev => ({
      ...prev,
      warnings: prev.warnings.map(w => w.id === id ? { ...w, [field]: value } : w)
    }));
  };

  const removeWarning = (id: string) => {
    setData(prev => ({ ...prev, warnings: prev.warnings.filter(w => w.id !== id) }));
  };

  // AI Generation
  const handleGenerateSummary = async () => {
    setIsGenerating(true);
    try {
      const summary = await generatePerformanceSummary(data);
      setData(prev => ({ ...prev, globalComments: summary }));
    } catch (e) {
      alert("Erreur lors de la génération");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleTeamAnalysis = async (period: string) => {
    setIsAnalyzingTeam(true);
    try {
        const result = await generateTeamBriefing(data, period);
        setTeamAnalysisResult(result);
    } catch (e) {
        alert("Erreur lors de l'analyse d'équipe");
    } finally {
        setIsAnalyzingTeam(false);
    }
  };

  // PDF Download
  const handleDownloadPDF = async () => {
    const element = document.getElementById('evaluation-form');
    if (!element) return;

    setIsDownloading(true);

    try {
        // Wait a moment for icons/images to be fully rendered if needed
        await new Promise(resolve => setTimeout(resolve, 100));

        const canvas = await html2canvas(element, {
            scale: 2, // Higher quality
            useCORS: true, // Handle cross-origin images (like blobs)
            logging: false,
            backgroundColor: '#f3f4f6' // Match body background
        });

        const imgData = canvas.toDataURL('image/jpeg', 0.9);
        
        // Create PDF with dimensions matching the content
        // This creates a single long page which is good for digital records
        const pdf = new jsPDF({
            orientation: 'portrait',
            unit: 'px',
            format: [canvas.width, canvas.height]
        });

        pdf.addImage(imgData, 'JPEG', 0, 0, canvas.width, canvas.height);
        
        const fileName = `Evaluation_${data.employee.name.replace(/\s+/g, '_') || 'Employe'}_${new Date().toISOString().slice(0,10)}.pdf`;
        pdf.save(fileName);

    } catch (err) {
        console.error("PDF generation failed", err);
        alert("Erreur lors de la génération du PDF.");
    } finally {
        setIsDownloading(false);
    }
  };

  // --- Render ---

  return (
    <div className="min-h-screen pb-24 font-inter">
      
      {/* Signature Modal Overlay */}
      <SignatureModal 
        isOpen={!!signingTarget}
        onClose={() => setSigningTarget(null)}
        onSave={handleSignatureSave}
        title={signingTarget?.title || 'Signature'}
      />

      {/* Main Content to be Printed */}
      <div id="evaluation-form" className="max-w-3xl mx-auto md:p-6 p-2 space-y-6 bg-[#f3f4f6]">
          {/* Header Title */}
          <header className="bg-indigo-600 text-white p-6 rounded-2xl shadow-lg mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold">Fiche d'Évaluation</h1>
                <p className="text-indigo-100 opacity-90 text-sm mt-1">Caissier(e) et Aide Caissier</p>
              </div>
              <FileText className="w-8 h-8 opacity-80" />
            </div>
          </header>

          {/* 1. Employee Information */}
          <Card title="Information Employé" className="border-l-4 border-l-indigo-500">
            <div className="flex flex-col md:flex-row gap-6">
              {/* Photo Upload */}
              <div className="flex flex-col items-center gap-2">
                <div className="w-24 h-24 bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center overflow-hidden relative group cursor-pointer">
                  {data.employee.photoUrl ? (
                    <img src={data.employee.photoUrl} alt="Employee" className="w-full h-full object-cover" />
                  ) : (
                    <User className="w-8 h-8 text-gray-400" />
                  )}
                  <input type="file" accept="image/*" onChange={handlePhotoUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
                  <div className="absolute inset-0 bg-black bg-opacity-40 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity">
                    <Upload className="w-5 h-5" />
                  </div>
                </div>
                <span className="text-xs text-gray-500">Photo</span>
              </div>

              {/* Fields */}
              <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="col-span-full flex gap-2">
                   <div className="flex-1">
                     <label className="text-xs font-semibold text-gray-500 uppercase">Début Période</label>
                     <input 
                        type="date" 
                        value={data.employee.periodStart}
                        onChange={(e) => handleEmployeeChange('periodStart', e.target.value)}
                        className="w-full mt-1 p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                     />
                   </div>
                   <div className="flex-1">
                     <label className="text-xs font-semibold text-gray-500 uppercase">Fin Période</label>
                     <input 
                        type="date" 
                        value={data.employee.periodEnd}
                        onChange={(e) => handleEmployeeChange('periodEnd', e.target.value)}
                        className="w-full mt-1 p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                     />
                   </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-gray-500 uppercase">Nom Complet</label>
                  <input 
                    type="text" 
                    placeholder="ex: Jean Dupont"
                    value={data.employee.name}
                    onChange={(e) => handleEmployeeChange('name', e.target.value)}
                    className="w-full mt-1 p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-500 uppercase">Matricule</label>
                  <input 
                    type="text" 
                    placeholder="ex: 12345"
                    value={data.employee.id}
                    onChange={(e) => handleEmployeeChange('id', e.target.value)}
                    className="w-full mt-1 p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
                <div className="col-span-full">
                  <label className="text-xs font-semibold text-gray-500 uppercase">Responsable</label>
                  <input 
                    type="text" 
                    placeholder="Nom du responsable"
                    value={data.employee.manager}
                    onChange={(e) => handleEmployeeChange('manager', e.target.value)}
                    className="w-full mt-1 p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
              </div>
            </div>
          </Card>

          {/* 2. Retards & Entrées Tardives */}
          <Card 
            title="1. Retards & Entrées Tardives" 
            className="border-l-4 border-l-yellow-500"
            action={
              <button onClick={addLateness} className="flex items-center gap-1 text-sm text-indigo-600 font-medium hover:bg-indigo-50 px-2 py-1 rounded transition" data-html2canvas-ignore="true">
                <Plus className="w-4 h-4" /> Ajouter
              </button>
            }
          >
            <div className="space-y-3">
              {data.latenessList.length === 0 && (
                <p className="text-center text-gray-400 py-4 text-sm italic">Aucun retard enregistré ce mois-ci.</p>
              )}
              {data.latenessList.map((item) => (
                <div key={item.id} className="bg-gray-50 p-3 rounded-lg relative border border-gray-100">
                  <button onClick={() => removeLateness(item.id)} className="absolute top-2 right-2 text-gray-400 hover:text-red-500" data-html2canvas-ignore="true">
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-2">
                    <div>
                        <label className="text-[10px] text-gray-500 uppercase block">Date</label>
                        <input type="date" value={item.date} onChange={(e) => updateLateness(item.id, 'date', e.target.value)} className="text-sm bg-transparent border-b border-gray-300 w-full py-1 focus:border-indigo-500 outline-none"/>
                    </div>
                    <div>
                        <label className="text-[10px] text-gray-500 uppercase block">Prévue</label>
                        <input type="time" value={item.expectedTime} onChange={(e) => updateLateness(item.id, 'expectedTime', e.target.value)} className="text-sm bg-transparent border-b border-gray-300 w-full py-1 focus:border-indigo-500 outline-none"/>
                    </div>
                    <div>
                        <label className="text-[10px] text-gray-500 uppercase block">Réelle</label>
                        <input type="time" value={item.actualTime} onChange={(e) => updateLateness(item.id, 'actualTime', e.target.value)} className="text-sm bg-transparent border-b border-gray-300 w-full py-1 focus:border-indigo-500 outline-none"/>
                    </div>
                    <div>
                        <label className="text-[10px] text-gray-500 uppercase block">Retard (min)</label>
                        <span className={`font-bold block py-1 ${item.delayMinutes > 0 ? 'text-red-600' : 'text-green-600'}`}>{item.delayMinutes} min</span>
                    </div>
                  </div>
                  <div className="flex gap-3 items-end">
                    <div className="flex-grow">
                      <label className="text-[10px] text-gray-500 uppercase block">Motif</label>
                      <input 
                        type="text" 
                        placeholder="Raison du retard..." 
                        value={item.reason}
                        onChange={(e) => updateLateness(item.id, 'reason', e.target.value)}
                        className="w-full text-sm bg-white border border-gray-200 rounded px-2 py-1 mt-1 focus:ring-1 focus:ring-indigo-500 outline-none"
                      />
                    </div>
                    <div className="w-1/3 flex flex-col justify-end">
                        <label className="text-[10px] text-gray-500 uppercase block mb-1">Signature</label>
                        {item.signature ? (
                            <div className="relative group border border-gray-200 bg-white rounded h-10 overflow-hidden">
                                <img src={item.signature} alt="Signature" className="w-full h-full object-contain" />
                                <div className="absolute inset-0 bg-black bg-opacity-10 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer"
                                     onClick={() => openSignatureModal('lateness', item.id, 'Modifier Signature')}
                                >
                                    <PenTool className="w-3 h-3 text-gray-700" />
                                </div>
                            </div>
                        ) : (
                            <button 
                                onClick={() => openSignatureModal('lateness', item.id, 'Signature du retard')}
                                className="w-full bg-indigo-50 text-indigo-600 text-xs py-2 rounded border border-indigo-100 hover:bg-indigo-100 transition flex items-center justify-center gap-1"
                            >
                                <PenTool className="w-3 h-3" /> Signer
                            </button>
                        )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-4 pt-4 border-t border-gray-100">
                <div className="flex justify-between items-center mb-3">
                    <span className="font-semibold text-gray-700">Total Retard:</span>
                    <span className="bg-gray-100 px-3 py-1 rounded-full font-mono font-bold">
                        {data.latenessList.reduce((acc, curr) => acc + curr.delayMinutes, 0)} min
                    </span>
                </div>
                <textarea 
                    placeholder="Commentaires sur l'assiduité..."
                    value={data.latenessComments}
                    onChange={(e) => setData(prev => ({...prev, latenessComments: e.target.value}))}
                    className="w-full p-2 text-sm border rounded-lg h-20 resize-none focus:ring-2 focus:ring-yellow-200 outline-none"
                ></textarea>
            </div>
          </Card>

          {/* 3. Erreurs & Incidents */}
          <Card 
            title="2. Erreurs & Incidents" 
            className="border-l-4 border-l-red-500"
            action={
              <button onClick={addError} className="flex items-center gap-1 text-sm text-red-600 font-medium hover:bg-red-50 px-2 py-1 rounded transition" data-html2canvas-ignore="true">
                <Plus className="w-4 h-4" /> Signaler
              </button>
            }
          >
             <div className="space-y-3">
              {data.errorList.length === 0 && (
                <div className="flex flex-col items-center justify-center py-6 text-green-600 bg-green-50 rounded-lg border border-green-100 border-dashed">
                    <CheckCircle className="w-8 h-8 mb-2 opacity-50" />
                    <p className="text-sm font-medium">Aucune erreur signalée. Excellent !</p>
                </div>
              )}
              {data.errorList.map((item) => (
                 <div key={item.id} className="bg-white shadow-sm border border-red-100 p-4 rounded-lg relative group">
                    <button onClick={() => removeError(item.id)} className="absolute top-2 right-2 text-gray-300 hover:text-red-500" data-html2canvas-ignore="true">
                        <Trash2 className="w-4 h-4" />
                    </button>
                    
                    <div className="flex justify-between items-start mb-3">
                        <div className="w-1/3">
                            <label className="text-[10px] text-gray-500 uppercase block">Date</label>
                            <input type="date" value={item.date} onChange={(e) => updateError(item.id, 'date', e.target.value)} className="text-sm font-medium bg-transparent outline-none"/>
                        </div>
                        <div className="flex items-center gap-2">
                            <label className="flex items-center cursor-pointer">
                                <input 
                                    type="checkbox" 
                                    checked={item.isRepeated} 
                                    onChange={(e) => updateError(item.id, 'isRepeated', e.target.checked)}
                                    className="w-4 h-4 text-red-600 rounded focus:ring-red-500 border-gray-300"
                                />
                                <span className="ml-2 text-xs font-semibold text-red-600 uppercase">Répétition?</span>
                            </label>
                        </div>
                    </div>

                    <div className="mb-3">
                        <label className="text-[10px] text-gray-500 uppercase block mb-1">Nature de l'erreur</label>
                        <input 
                          type="text" 
                          className="w-full p-2 text-sm bg-red-50 border-0 rounded focus:ring-1 focus:ring-red-200 outline-none"
                          placeholder="Ex: Erreur de rendu monnaie..."
                          value={item.nature}
                          onChange={(e) => updateError(item.id, 'nature', e.target.value)}
                        />
                    </div>

                    <div className="flex justify-end items-end">
                        <div className="w-1/3">
                            <label className="text-[10px] text-gray-500 uppercase block text-right mb-1">Signature</label>
                            {item.signature ? (
                                <div className="relative group border border-gray-200 bg-white rounded h-10 overflow-hidden ml-auto" onClick={() => openSignatureModal('error', item.id, 'Visa erreur')}>
                                    <img src={item.signature} alt="Signature" className="w-full h-full object-contain" />
                                </div>
                            ) : (
                                <button 
                                    onClick={() => openSignatureModal('error', item.id, 'Visa erreur')}
                                    className="w-full bg-red-50 text-red-600 text-xs py-2 rounded border border-red-100 hover:bg-red-100 transition flex items-center justify-center gap-1"
                                >
                                    <PenTool className="w-3 h-3" /> Visa
                                </button>
                            )}
                        </div>
                    </div>
                 </div>
              ))}
             </div>
             
             <div className="mt-4 pt-4 border-t border-gray-100 text-sm">
                <div className="flex justify-between py-1">
                    <span className="text-gray-600">Nombre total d'erreurs:</span>
                    <span className="font-bold">{data.errorList.length}</span>
                </div>
                <div className="flex justify-between py-1 text-red-600">
                    <span>Nombre d'erreurs répétées:</span>
                    <span className="font-bold">{data.errorList.filter(e => e.isRepeated).length}</span>
                </div>
                {data.errorList.filter(e => e.isRepeated).length >= 2 && (
                    <div className="mt-2 bg-red-100 text-red-800 p-2 rounded text-xs font-bold flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4" />
                        2+ ERREURS RÉPÉTÉES → AVERTISSEMENT ET SANCTION
                    </div>
                )}
             </div>
          </Card>

          {/* 4. Avertissements */}
          <Card title="3. Avertissements" className="border-l-4 border-l-orange-500">
            {data.warnings.length === 0 ? (
                <div className="text-center py-4">
                    <button onClick={addWarning} className="text-sm text-orange-500 hover:underline flex items-center justify-center gap-2 w-full" data-html2canvas-ignore="true">
                        <Plus className="w-4 h-4" /> Ajouter un avertissement
                    </button>
                    <p className="text-sm text-gray-400 italic">Aucun avertissement.</p>
                </div>
            ) : (
                <div className="space-y-3">
                    {data.warnings.map(w => (
                        <div key={w.id} className="border border-orange-200 bg-orange-50 rounded p-3 relative">
                             <button onClick={() => removeWarning(w.id)} className="absolute top-2 right-2 text-orange-300 hover:text-orange-600" data-html2canvas-ignore="true">
                                <Trash2 className="w-4 h-4" />
                            </button>
                            <div className="mb-2">
                                <label className="text-[10px] text-gray-500 uppercase block">Date</label>
                                <input type="date" value={w.date} onChange={(e) => updateWarning(w.id, 'date', e.target.value)} className="bg-transparent text-sm font-medium outline-none" />
                            </div>
                            <textarea 
                                placeholder="Motif de l'avertissement..."
                                className="w-full bg-white p-2 rounded text-sm border border-orange-200 outline-none resize-none mb-2"
                                value={w.reason}
                                onChange={(e) => updateWarning(w.id, 'reason', e.target.value)}
                            />
                            <div>
                                <label className="text-[10px] text-orange-800 uppercase block mb-1">Signature du Caissier</label>
                                {w.signature ? (
                                    <div className="border border-orange-200 bg-white rounded h-12 overflow-hidden cursor-pointer" onClick={() => openSignatureModal('warning', w.id, 'Signature Caissier')}>
                                        <img src={w.signature} alt="Signature" className="w-full h-full object-contain" />
                                    </div>
                                ) : (
                                    <button 
                                        onClick={() => openSignatureModal('warning', w.id, 'Signature Caissier')}
                                        className="w-full bg-white text-orange-600 text-xs py-2 rounded border border-orange-200 hover:bg-orange-100 transition flex items-center justify-center gap-1"
                                    >
                                        <PenTool className="w-3 h-3" /> Signer l'avertissement
                                    </button>
                                )}
                            </div>
                        </div>
                    ))}
                     <button onClick={addWarning} className="text-xs text-orange-500 hover:underline mt-2 flex items-center gap-1" data-html2canvas-ignore="true">
                        <Plus className="w-3 h-3" /> Ajouter un autre
                    </button>
                </div>
            )}
          </Card>

          {/* 5. Prime de Performance */}
          <Card title="4. Prime de Performance" className="border-l-4 border-l-green-500">
            <div className="flex flex-col items-center gap-4 py-2">
                <h4 className="text-sm font-medium text-gray-700">Aucune erreur constatée durant le mois ?</h4>
                
                <div className="flex flex-col sm:flex-row items-center gap-6">
                    {/* Manual Selection Buttons */}
                    <div 
                        onClick={() => setData(prev => ({...prev, performanceBonus: true}))}
                        className={`cursor-pointer flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all duration-300 hover:shadow-md ${data.performanceBonus ? 'border-green-500 bg-green-50 scale-105' : 'border-gray-100 bg-white hover:bg-gray-50 opacity-70'}`}
                    >
                         <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${data.performanceBonus ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-400'}`}>
                            <CheckCircle className="w-5 h-5" />
                         </div>
                         <span className={`font-bold ${data.performanceBonus ? 'text-green-700' : 'text-gray-500'}`}>PRIME ACCORDÉE</span>
                    </div>

                    <div 
                        onClick={() => setData(prev => ({...prev, performanceBonus: false}))}
                        className={`cursor-pointer flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all duration-300 hover:shadow-md ${!data.performanceBonus ? 'border-red-500 bg-red-50 scale-105' : 'border-gray-100 bg-white hover:bg-gray-50 opacity-70'}`}
                    >
                         <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${!data.performanceBonus ? 'bg-red-500 text-white' : 'bg-gray-200 text-gray-400'}`}>
                            <XCircle className="w-5 h-5" />
                         </div>
                         <span className={`font-bold ${!data.performanceBonus ? 'text-red-700' : 'text-gray-500'}`}>PAS DE PRIME</span>
                    </div>
                </div>
                
                <p className="text-xs text-gray-400 italic mt-2">Sélection manuelle par le responsable</p>
            </div>
          </Card>
        
          {/* New: Analyse d'Équipe (IA) */}
          <Card title="5. Outils Manager & Analyse d'Équipe (IA)" className="border-l-4 border-l-blue-500" data-html2canvas-ignore="true">
              <div className="space-y-3">
                  <p className="text-sm text-gray-600">Générez un briefing ou une analyse pour toute l'équipe basé sur les tendances observées :</p>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                      {['Journée', 'Semaine', '15 Jours', 'Mois'].map((period) => (
                          <button
                            key={period}
                            onClick={() => handleTeamAnalysis(period)}
                            disabled={isAnalyzingTeam}
                            className="bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 py-2 px-3 rounded-lg text-sm font-medium transition flex items-center justify-center gap-1 disabled:opacity-50"
                          >
                              {isAnalyzingTeam ? <div className="w-3 h-3 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div> : <Users className="w-4 h-4" />}
                              {period}
                          </button>
                      ))}
                  </div>

                  {teamAnalysisResult && (
                      <div className="mt-3 bg-blue-50 border border-blue-100 p-3 rounded-lg relative animate-fade-in">
                           <h4 className="text-xs font-bold text-blue-800 uppercase mb-2 flex items-center gap-1">
                               <Calendar className="w-3 h-3" /> Résultat de l'analyse
                           </h4>
                           <textarea 
                                className="w-full h-32 bg-transparent border-0 text-sm text-gray-700 resize-none outline-none"
                                value={teamAnalysisResult}
                                readOnly
                           />
                           <button 
                            onClick={() => setTeamAnalysisResult("")}
                            className="absolute top-2 right-2 text-blue-300 hover:text-blue-600"
                           >
                               <XCircle className="w-4 h-4" />
                           </button>
                      </div>
                  )}
              </div>
          </Card>

          {/* Final Comments & AI */}
          <Card title="Commentaires Globaux" className="border-t-4 border-t-indigo-600">
            <div className="space-y-4">
                <div className="flex justify-end">
                    <button 
                        onClick={handleGenerateSummary}
                        disabled={isGenerating}
                        className="flex items-center gap-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-4 py-2 rounded-lg shadow-md hover:shadow-lg transition-all text-sm disabled:opacity-70"
                        data-html2canvas-ignore="true"
                    >
                        {isGenerating ? (
                            <span className="animate-pulse">Génération...</span>
                        ) : (
                            <>
                              <Wand2 className="w-4 h-4" />
                              Générer un résumé IA
                            </>
                        )}
                    </button>
                </div>
                <textarea 
                    className="w-full h-32 p-3 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none leading-relaxed"
                    placeholder="Synthèse du responsable..."
                    value={data.globalComments}
                    onChange={(e) => setData(prev => ({...prev, globalComments: e.target.value}))}
                ></textarea>
            </div>
          </Card>

          {/* Footer Signatures */}
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
                <label className="text-xs font-bold text-gray-400 uppercase block mb-2">Signature du Caissier(e)</label>
                {data.employeeSignature ? (
                    <div className="relative group border-b-2 border-gray-200 h-20 cursor-pointer" onClick={() => openSignatureModal('main_employee', undefined, 'Signature Caissier(e)')}>
                       <img src={data.employeeSignature} alt="Employee Signature" className="h-full object-contain" />
                       <button className="absolute top-0 right-0 p-1 bg-gray-100 rounded-full opacity-0 group-hover:opacity-100 transition"><PenTool className="w-3 h-3 text-gray-600"/></button>
                    </div>
                ) : (
                    <button 
                        onClick={() => openSignatureModal('main_employee', undefined, 'Signature Caissier(e)')}
                        className="w-full h-20 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center text-gray-400 hover:border-indigo-400 hover:text-indigo-500 transition"
                    >
                        <PenTool className="w-6 h-6 mb-1" />
                        <span className="text-sm font-medium">Cliquer pour signer</span>
                    </button>
                )}
            </div>
            <div>
                <label className="text-xs font-bold text-gray-400 uppercase block mb-2">Signature du Responsable</label>
                {data.managerSignature ? (
                    <div className="relative group border-b-2 border-gray-200 h-20 cursor-pointer" onClick={() => openSignatureModal('main_manager', undefined, 'Signature Responsable')}>
                       <img src={data.managerSignature} alt="Manager Signature" className="h-full object-contain" />
                       <button className="absolute top-0 right-0 p-1 bg-gray-100 rounded-full opacity-0 group-hover:opacity-100 transition"><PenTool className="w-3 h-3 text-gray-600"/></button>
                    </div>
                ) : (
                    <button 
                        onClick={() => openSignatureModal('main_manager', undefined, 'Signature Responsable')}
                        className="w-full h-20 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center text-gray-400 hover:border-indigo-400 hover:text-indigo-500 transition"
                    >
                        <PenTool className="w-6 h-6 mb-1" />
                        <span className="text-sm font-medium">Cliquer pour signer</span>
                    </button>
                )}
            </div>
            <div className="md:col-span-2 flex justify-end pt-4 border-t border-gray-100">
                 <div className="text-right">
                    <label className="text-[10px] text-gray-400 uppercase block">Fait le</label>
                    <input 
                        type="date" 
                        value={data.signatureDate} 
                        onChange={(e) => setData(prev => ({...prev, signatureDate: e.target.value}))}
                        className="text-sm font-medium text-gray-600 bg-transparent outline-none text-right"
                    />
                 </div>
            </div>
          </div>
      </div>

      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 right-6 flex flex-col gap-3 z-40">
        <button 
            onClick={handleDownloadPDF} 
            disabled={isDownloading}
            className="bg-white text-gray-700 p-4 rounded-full shadow-lg hover:shadow-xl border border-gray-200 hover:bg-gray-50 transition-all flex items-center gap-2 disabled:opacity-70"
        >
            <DownloadCloud className={`w-6 h-6 ${isDownloading ? 'animate-bounce' : ''}`} />
            <span className="hidden md:inline font-semibold">{isDownloading ? 'Génération...' : 'Télécharger PDF'}</span>
        </button>
        
        <button className="bg-indigo-600 text-white p-4 rounded-full shadow-xl hover:bg-indigo-700 transition-colors flex items-center gap-2">
            <Save className="w-6 h-6" />
            <span className="hidden md:inline font-semibold">Enregistrer</span>
        </button>
      </div>

    </div>
  );
};

export default App;