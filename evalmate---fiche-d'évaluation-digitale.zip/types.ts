export interface EmployeeInfo {
  periodStart: string;
  periodEnd: string;
  name: string;
  id: string; // Matricule
  manager: string;
  photoUrl?: string;
}

export interface LatenessEntry {
  id: string;
  date: string;
  expectedTime: string;
  actualTime: string;
  delayMinutes: number;
  reason: string;
  signature: string;
}

export interface ErrorEntry {
  id: string;
  date: string;
  nature: string;
  isRepeated: boolean;
  signature: string;
}

export interface WarningEntry {
  id: string;
  date: string;
  reason: string;
  signature: string;
}

export interface EvaluationData {
  employee: EmployeeInfo;
  latenessList: LatenessEntry[];
  latenessComments: string;
  errorList: ErrorEntry[];
  warnings: WarningEntry[];
  performanceBonus: boolean; // Prime
  globalComments: string;
  managerSignature: string;
  employeeSignature: string;
  signatureDate: string;
}
